import { useState, useEffect, useCallback } from "react";
import EARTH_BG_LOCAL from "./assets/earth-day-bg.png";
import SPRING_PRIZE from "./assets/spring-fest-prize.png";
import EARTH_PRIZE from "./assets/earth-day-prize.png";

// ─── Asset URLs from Figma ───
// Spring Focus Fest
const SPRING_BG = "https://www.figma.com/api/mcp/asset/0742cf58-6fd9-4ec9-9f4c-a81acfa7ae22";      // node 519:18144
const SPRING_TREE = "https://www.figma.com/api/mcp/asset/d122b102-cef2-43ec-be5f-d26c745ef320";    // node 519:18147
// Earth Day
const EARTH_BG = EARTH_BG_LOCAL;
const EARTH_TREE = "https://www.figma.com/api/mcp/asset/0f0ce6e5-04b6-4756-b419-954cb7cb8319";     // node 606:51407

// ─── Event data ───
const EVENTS = [
  {
    id: "spring-focus-fest",
    title: "Spring Focus Fest",
    titleZh: "春日專注祭",
    badge: "2 days left",
    badgeType: "ing",
    iconImg: SPRING_PRIZE,
    bgImg: SPRING_BG,
    bgFlip: false,
    bgPosition: "50% 78%",
  },
  {
    id: "earth-day",
    title: "Earth day",
    titleZh: "地球日 捐贈能量種真樹",
    badge: "Coming soon",
    badgeType: "coming-soon",
    iconImg: EARTH_PRIZE,
    bgImg: EARTH_BG,
    bgFlip: true,
    bgPosition: "50% 60%",
  },
];

// ─── Radial gradient background matching Figma ───
const BG_GRADIENT = `radial-gradient(ellipse at 66% 12%, rgba(255,255,255,1) 0%, rgba(235,254,243,1) 40%, rgba(197,239,217,1) 65%, rgba(159,224,192,1) 100%)`;

// ─── Loading spinner (CSS-only) ───
function Spinner() {
  return (
    <div style={{ width: 40, height: 40, position: "relative" }}>
      {Array.from({ length: 12 }).map((_, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            top: "50%",
            left: "50%",
            width: 3,
            height: 9,
            marginTop: -4.5,
            marginLeft: -1.5,
            borderRadius: 2,
            backgroundColor: "#4a9e8e",
            transform: `rotate(${i * 30}deg) translateY(-12px)`,
            opacity: 0.15 + (i / 12) * 0.85,
            animation: `spinFade 1s linear infinite`,
            animationDelay: `${(i / 12) * -1}s`,
          }}
        />
      ))}
      <style>{`
        @keyframes spinFade {
          0% { opacity: 1; }
          100% { opacity: 0.15; }
        }
      `}</style>
    </div>
  );
}

// ─── Badge component with Figma variants ───
function Badge({ type, text }) {
  return (
    <div
      style={{
        backgroundColor: "rgba(147,144,51,0.26)",
        borderRadius: 9,
        height: 20,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "2px 8px",
      }}
    >
      <span
        style={{
          fontFamily: "'SF Pro Text', -apple-system, BlinkMacSystemFont, sans-serif",
          fontSize: 12,
          fontWeight: 400,
          lineHeight: "16px",
          color: "#fff",
          whiteSpace: "nowrap",
        }}
      >
        {text}
      </span>
    </div>
  );
}

// ─── Event Card ───
function EventCard({ event, onClick }) {
  const [isPressed, setIsPressed] = useState(false);

  return (
    <a
      href="#"
      onClick={(e) => {
        e.preventDefault();
        onClick(event.id);
      }}
      onPointerDown={() => setIsPressed(true)}
      onPointerUp={() => setIsPressed(false)}
      onPointerCancel={() => setIsPressed(false)}
      onPointerLeave={() => setIsPressed(false)}
      onBlur={() => setIsPressed(false)}
      onKeyDown={(e) => {
        if (e.key === " " || e.key === "Enter") setIsPressed(true);
      }}
      onKeyUp={(e) => {
        if (e.key === " " || e.key === "Enter") setIsPressed(false);
      }}
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 12,
        position: "relative",
        overflow: "hidden",
        borderRadius: 30,
        border: "3px solid rgba(247,247,247,0.4)",
        padding: "16px 24px 12px 24px",
        width: "100%",
        textDecoration: "none",
        cursor: "pointer",
        boxSizing: "border-box",
        WebkitTapHighlightColor: "transparent",
      }}
    >
      {/* Background image */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          overflow: "hidden",
          transform: event.bgFlip ? "scaleX(-1)" : "none",
        }}
      >
        <img
          src={event.bgImg}
          alt=""
          style={{
            width: "100%",
            height: "100%",
            objectFit: "cover",
            objectPosition: event.bgPosition ?? "50% 50%",
            pointerEvents: "none",
          }}
        />
      </div>

      {/* Content row */}
      <div
        style={{
          display: "flex",
          flex: "1 0 0",
          gap: 16,
          alignItems: "center",
          position: "relative",
          minWidth: 0,
        }}
      >
        {/* Tree icon */}
        <div style={{ width: 80, height: 80, flexShrink: 0, position: "relative" }}>
          <img
            src={event.iconImg}
            alt=""
            style={{
              position: "absolute",
              inset: 0,
              width: "100%",
              height: "100%",
              objectFit: "contain",
              pointerEvents: "none",
            }}
          />
        </div>

        {/* Event title */}
        <div style={{ flex: "1 0 0", minWidth: 0 }}>
          <p
            style={{
              fontFamily: "'SF Pro Text', -apple-system, BlinkMacSystemFont, sans-serif",
              fontSize: 16,
              fontWeight: 600,
              lineHeight: "22px",
              color: "#fff",
              margin: 0,
              textAlign: "left",
            }}
          >
            {event.title}
          </p>
        </div>
      </div>

      {/* Badge */}
      <div
        style={{
          position: "absolute",
          top: 9.5,
          right: 12.5,
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-end",
        }}
      >
        <Badge type={event.badgeType} text={event.badge} />
      </div>

      {/* Press overlay */}
      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          inset: 0,
          background: "rgba(0,0,0,0.4)",
          opacity: isPressed ? 1 : 0,
          transition: "opacity 120ms ease",
          pointerEvents: "none",
        }}
      />
    </a>
  );
}

// ─── Loading State Screen ───
function LoadingScreen() {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        flex: 1,
        width: "100%",
      }}
    >
      <Spinner />
    </div>
  );
}

// ─── Event List Screen ───
function EventListScreen({ onNavigate, fadeIn }) {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        flex: 1,
        width: "100%",
        opacity: fadeIn ? 1 : 0,
        transition: "opacity 0.4s ease",
      }}
    >
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 24,
          alignItems: "center",
          width: "100%",
          maxWidth: 640,
          padding: "0 36px",
          boxSizing: "border-box",
        }}
      >
        {/* Page title */}
        <h1
          style={{
            fontFamily: "'SF Pro', -apple-system, BlinkMacSystemFont, sans-serif",
            fontSize: 20,
            fontWeight: 590,
            lineHeight: "28px",
            color: "#036059",
            textAlign: "center",
            margin: 0,
            width: "100%",
          }}
        >
          Event List
        </h1>

        {/* Event cards */}
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            gap: 24,
            width: "100%",
          }}
        >
          {EVENTS.map((event) => (
            <EventCard key={event.id} event={event} onClick={onNavigate} />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Event Detail Page (placeholder) ───
function EventDetailScreen({ eventId, onBack }) {
  const event = EVENTS.find((e) => e.id === eventId);
  if (!event) return null;

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        flex: 1,
        width: "100%",
        padding: "0 36px",
        boxSizing: "border-box",
        animation: "slideIn 0.35s ease forwards",
      }}
    >
      <style>{`
        @keyframes slideIn {
          from { opacity: 0; transform: translateX(24px); }
          to   { opacity: 1; transform: translateX(0); }
        }
      `}</style>

      <div
        style={{
          width: "100%",
          maxWidth: 640,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          gap: 32,
        }}
      >
        {/* Back button */}
        <button
          onClick={onBack}
          style={{
            alignSelf: "flex-start",
            background: "none",
            border: "none",
            cursor: "pointer",
            display: "flex",
            alignItems: "center",
            gap: 6,
            padding: "4px 0",
            color: "#036059",
            fontFamily: "'SF Pro Text', -apple-system, BlinkMacSystemFont, sans-serif",
            fontSize: 15,
            fontWeight: 600,
          }}
        >
          <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
            <path d="M12.5 15L7.5 10L12.5 5" stroke="#036059" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
          Back
        </button>

        {/* Hero card */}
        <div
          style={{
            width: "100%",
            borderRadius: 30,
            border: "3px solid rgba(247,247,247,0.4)",
            overflow: "hidden",
            position: "relative",
            minHeight: 200,
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              overflow: "hidden",
              transform: event.bgFlip ? "scaleX(-1)" : "none",
            }}
          >
            <img
              src={event.bgImg}
              alt=""
              style={{
                width: "100%",
                height: "100%",
                objectFit: "cover",
                pointerEvents: "none",
              }}
            />
          </div>
          <div
            style={{
              position: "relative",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              padding: "32px 24px",
              gap: 16,
            }}
          >
            <img
              src={event.iconImg}
              alt=""
              style={{ width: 120, height: 120, objectFit: "contain" }}
            />
            <h2
              style={{
                fontFamily: "'SF Pro', -apple-system, BlinkMacSystemFont, sans-serif",
                fontSize: 22,
                fontWeight: 700,
                color: "#fff",
                margin: 0,
                textAlign: "center",
              }}
            >
              {event.title}
            </h2>
            <Badge type={event.badgeType} text={event.badge} />
          </div>
        </div>

        {/* Description placeholder */}
        <div
          style={{
            width: "100%",
            padding: "24px",
            background: "rgba(255,255,255,0.6)",
            borderRadius: 20,
            backdropFilter: "blur(8px)",
          }}
        >
          <p
            style={{
              fontFamily: "'SF Pro Text', -apple-system, BlinkMacSystemFont, sans-serif",
              fontSize: 15,
              lineHeight: "22px",
              color: "#333",
              margin: 0,
              textAlign: "center",
            }}
          >
            {event.titleZh}
          </p>
          <p
            style={{
              fontFamily: "'SF Pro Text', -apple-system, BlinkMacSystemFont, sans-serif",
              fontSize: 13,
              lineHeight: "20px",
              color: "#666",
              margin: "12px 0 0",
              textAlign: "center",
            }}
          >
            Activity detail page — connect your real content here.
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── Back to Home Button ───
function BackToHomeButton({ onClick, visible }) {
  return (
    <button
      onClick={onClick}
      style={{
        width: "100%",
        maxWidth: 640,
        height: 52,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 16,
        borderRadius: 12,
        border: "none",
        background: "transparent",
        boxShadow: "0 0 20px -2px rgba(198,255,205,0.15)",
        cursor: "pointer",
        opacity: visible ? 1 : 0,
        transition: "opacity 0.3s ease",
        flexShrink: 0,
      }}
    >
      <span
        style={{
          fontFamily: "'SF Pro', -apple-system, BlinkMacSystemFont, sans-serif",
          fontSize: 16,
          fontWeight: 700,
          color: "#176361",
          textAlign: "center",
        }}
      >
        Back to Home
      </span>
    </button>
  );
}

// ─── App Shell ───
export default function ForestEvents2026() {
  const [screen, setScreen] = useState("loading"); // loading | list | detail
  const [selectedEventId, setSelectedEventId] = useState(null);
  const [listFadeIn, setListFadeIn] = useState(false);

  // Simulate loading
  useEffect(() => {
    const timer = setTimeout(() => {
      setScreen("list");
      setTimeout(() => setListFadeIn(true), 50);
    }, 1800);
    return () => clearTimeout(timer);
  }, []);

  const handleNavigateToEvent = useCallback((eventId) => {
    setSelectedEventId(eventId);
    setScreen("detail");
  }, []);

  const handleBack = useCallback(() => {
    setScreen("list");
    setListFadeIn(true);
    setSelectedEventId(null);
  }, []);

  const handleBackToHome = useCallback(() => {
    // In production: navigate out. Here we restart the flow.
    setScreen("loading");
    setListFadeIn(false);
    setSelectedEventId(null);
    setTimeout(() => {
      setScreen("list");
      setTimeout(() => setListFadeIn(true), 50);
    }, 1200);
  }, []);

  return (
    <div
      style={{
        width: "100%",
        minHeight: "100vh",
        height: "100%",
        background: BG_GRADIENT,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "space-between",
        paddingTop: 48,
        paddingBottom: 32,
        boxSizing: "border-box",
        overflow: "auto",
        position: "relative",
      }}
    >
      {/* Main content area */}
      {screen === "loading" && <LoadingScreen />}
      {screen === "list" && (
        <EventListScreen onNavigate={handleNavigateToEvent} fadeIn={listFadeIn} />
      )}
      {screen === "detail" && (
        <EventDetailScreen eventId={selectedEventId} onBack={handleBack} />
      )}

      {/* Bottom button */}
      <div
        style={{
          width: "100%",
          padding: "16px 0 0",
          display: "flex",
          justifyContent: "center",
        }}
      >
        <BackToHomeButton
          onClick={handleBackToHome}
          visible={screen !== "loading"}
        />
      </div>
    </div>
  );
}
